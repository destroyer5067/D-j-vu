from django.urls import path
from . import views
urlpatterns = [
    path('', views.home , name='dejavu-home'),
    path('about/',views.about , name= 'dejavu-about'),
    path('take',views.index , name= 'index'),
    
]
