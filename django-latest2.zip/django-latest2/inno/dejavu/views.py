from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.core.files.storage import FileSystemStorage
from django.db import models
import docx2txt
import difflib
import nltk
import PyPDF2
import requests
from bs4 import BeautifulSoup


def login(request):
    return render(request, 'users/login.html')


def home(request):
    return render(request, 'dejavu/home.html')


def about(request):
    return render(request, 'dejavu/about.html')


def index(request):

    djtext1 = request.POST['t1']
    djtext2 = request.POST['t2']
    state1 = request.POST.get('x1', 'off')
    state2 = request.POST.get('x2', 'off')
    flag = 0
    m1 = len(djtext1)
    m2 = len(djtext2)
    if m1 == 33 and m2 == 33:
        flag = 1
    if state1 == "on" or state2 == "on":
        if state1 == "on":
            url1 = request.POST.get('u1')
            r1 = requests.get(url1)
            htmlcontent1 = r1.content
            soup1 = BeautifulSoup(htmlcontent1, 'html.parser')
            link = soup1.find('td').get_text()

        if state2 == "on":
            url2 = request.POST.get('u2')
            r2 = requests.get(url2)
            htmlcontent2 = r2.content
            soup2 = BeautifulSoup(htmlcontent2, 'html.parser')
            link = soup2.find('article').get_text()
        if m2 == 18:
            seq = difflib.SequenceMatcher(None, djtext1, link)
            d = seq.ratio()*100
            d = round(d, 2)
            x = ""
            x = str(d)
            params = {'text1': djtext1, 'text2': link,
                      'res': flag, 'len1': m1, 'len2': m2, 'ans': x}
            return render(request, 'result.html', params)
        elif request.method == 'POST':

            bfile1 = request.FILES['f1']
            ext1 = bfile1.name
            if ext1[-1] == 'x':
                z = docx2txt.process(bfile1)
            elif ext1[-1] == 'f':
                x1 = PyPDF2.PdfFileReader(bfile1)
                z = " "
                num = x1.getNumPages()
                for i in range(1, num):
                    z += x1.getPage(i).extractText()
            seq = difflib.SequenceMatcher(None, link, z)
            d = seq.ratio()*100
            d = round(d, 2)
            x = " "
            x = str(d)
            params = {'text1': z, 'text2': link, 'res': flag,
                      'len1': m1, 'len2': m2, 'ans': x}
            return render(request, 'result.html', params)

    elif request.method == 'POST' and flag == 1:

        bfile1 = request.FILES['f1']
        bfile2 = request.FILES['f2']

        ext1 = bfile1.name
        ext2 = bfile2.name

        if ext1[-1] == 'x':
            z = docx2txt.process(bfile1)
        elif ext1[-1] == 'f':
            x1 = PyPDF2.PdfFileReader(bfile1)
            z = " "
            num = x1.getNumPages()
            for i in range(1, num):
                z += x1.getPage(i).extractText()

        if ext2[-1] == 'x':
            y = docx2txt.process(bfile2)

        elif ext2[-1] == 'f':
            x2 = PyPDF2.PdfFileReader(bfile2)
            y = " "
            num = x2.getNumPages()
            for i in range(1, num):
                y += x2.getPage(i).extractText()
        seq = difflib.SequenceMatcher(None, y, z)
        d = seq.ratio()*100
        d = round(d, 2)
        x = " "
        x = str(d)
        params = {'text1': z, 'text2': y, 'res': flag,
                  'len1': m1, 'len2': m2, 'ans': x}
        return render(request, 'result.html', params)
    else:
        seq = difflib.SequenceMatcher(None, djtext1, djtext2)
        d = seq.ratio()*100
        d = round(d, 2)
        x = ""
        x = str(d)
        params = {'text1': djtext1, 'text2': djtext2,
                  'res': flag, 'len1': m1, 'len2': m2, 'ans': x}
        return render(request, 'result.html', params)
