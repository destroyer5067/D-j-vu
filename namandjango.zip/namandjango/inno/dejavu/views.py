from django.shortcuts import render
from django.contrib.auth.decorators import login_required
import docx2txt
import difflib
import nltk
import PyPDF2
# Create your views here.


def login(request):
    return render(request, 'users/login.html')


def home(request):
    return render(request, 'dejavu/home.html')

# def home(request):
#	context={
#		'copy' : copy
#	}
#	return render(request,'dejavu/home.html',context)


def about(request):
    return render(request, 'dejavu/about.html')


def index(request):
    djtext1 = request.POST.get('t1', 'default')
    djtext2 = request.POST.get('t2', 'default')
   # taking other formats as input
    # if request.method == 'POST':
    # files1 = request.FILES.getlist('f1')
    # pdf_data1 = []
    # for filename in files1:
    #  read_pdf = PyPDF2.PdfFileReader(open(files1))
    #  page = read_pdf.getPage(0)
    # page_content = page.extractText()
    # pdf_data1.append(page_content)
    seq = difflib.SequenceMatcher(None, djtext1, djtext2)

    d = seq.ratio()*100

    x = ""
    x = str(d)
    params = {'text1': djtext1, 'text2': x}
    return render(request, 'result.html', params)
