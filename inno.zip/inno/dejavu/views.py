from django.shortcuts import render
from django.contrib.auth.decorators import login_required

# Create your views here.
def login(request):
  return render(request, 'users/login.html')


def home(request):
  return render(request, 'dejavu/home.html')

#def home(request):
#	context={
#		'copy' : copy
#	}
#	return render(request,'dejavu/home.html',context)

def about(request):
	return render(request,'dejavu/about.html')