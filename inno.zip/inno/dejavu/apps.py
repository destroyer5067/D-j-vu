from django.apps import AppConfig


class DejavuConfig(AppConfig):
    name = 'dejavu'
